import UIKit

protocol Driver {
    var name: String { get }
    func driveToDestination(_ destination: String, with food: String)
}
class DeliveryDriver: Driver {
    let name: String
    init(name: String) {
        self.name = name
    }
    func driveToDestination(_ destination: String, with food: String) {
        print("\(name) is driving to \(destination) to deliver \(food).")
    }
}

class LittleLemon {
    var deliveryDriver: Driver?
    //Define a food delivery method
    func deliverFood (_ food: String ,to destination:String){
        //Inside the deliverFood method, use an if let statement to safely unwrap deliveryDriver and assign the successfully unwrapped value to the deliveryDriver constant.
        if let deliveryDriver = deliveryDriver {
            // Step 6: Delegate the food delivery functionality
            
            deliveryDriver.driveToDestination(destination, with: food)
            
        }else {
            print("No delivery driver.")
        }
        
    }}

// Instantiate a DeliveryDriver with the name "Bob"
let bob = DeliveryDriver(name: "Bob")
// Instantiate a LittleLemon class instance and assign it to a littleLemon constant
let littleLemon = LittleLemon()
littleLemon.deliverFood("Super Spaghetti", to: "1 Spaghetti Lane")
littleLemon.deliveryDriver = bob
littleLemon.deliverFood("Super Spaghetti", to: "1 Spaghetti Lane")

